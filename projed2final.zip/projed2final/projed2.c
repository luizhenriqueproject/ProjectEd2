#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <time.h>


void inverter(int *v,int n)
{

    int i, aux;

    for (i=0; i < n/2; i++){
        aux = v[i];
        v[i] = v[n-i-1];
        v[n-i-1] = aux;
    }
    printf("\n");
    printf("\n");
}




int escolheqtd(){
    int n;
    printf("\n\t\tEscolha a quantidade de elementos: \n");
    printf("\t\t1000, 5000, 10000, 20000, 50000, 100000.\n");
    printf("\tVoc� pode tamb�m escolher um n�mero entre 1000 e 100000.\n");
    scanf("%d", &n);

    if(n == 1000 || n == 5000 || n == 10000 || n == 20000 ||n == 50000 || n == 100000 || n > 1000 && n < 100000){
        printf("\n    A qtd escolhida foi: %d\n", n);
        return n;

    }

    system("cls");
    printf("\n\t\t\tDigite uma op��o v�lida!\n");
    escolheqtd();
}

int alocavetor(int qtd){

    int *vetor;

    vetor = (int*) malloc (qtd * sizeof(int));

    if(vetor == NULL){
        printf("\nA aloca��o falhou!\n");
    }
    else{
        return vetor;
    }
}

void atribuiElementos(int *vetor,int qtd){
    int i;
    srand(time(NULL));
    for(i = 0; i< qtd; i++){
        vetor[i] =  rand()%qtd;
    }
}

void mediaTempoOrd(double vetor[]){

    int i;
    double sum;
    double media;
    int conversao;

    for(i= 0; i<10; i++){

        conversao =  vetor[i];

        sum = sum + conversao;
    }

    media = sum / 10;

    printf("\n\n\t\t\t\tA media e: %g", media);

}


void Ordena_bubbleSort(int *v, int n){

    int i, continua, aux, fim = n;
    float media;
    do{
        continua = 0;
        for(i = 0; i < fim - 1; i++){
            if(v[i] > v[i+1]){
                aux = v[i];
                v[i] = v[i+1];
                v[i+1] = aux;
                continua = i;
            }
        }
    fim--;
    }while(continua != 0);



}

void criaHeap(int *v, int i, int f){
	int aux = v[i];
	int j = i*2+1;
	while(j<=f){
		if(j<f){
			if(v[j] < v[j + 1]){
				j =  j + 1;
            }
        }
    if(aux < v[j]){
        v[i] = v[j];
        i = j;
        j = 2 * i + 1;
    }else{
        j = f + 1;
    }
    }
    v[i] = aux;
}

void Ordena_heapSort(int *v, int n){
    int i, aux;
    for (i = (n - 1)/2; i>=0; i--){
        criaHeap(v, i, n - 1);
    }
    for(i = n - 1; i >= 1; i--){
        aux = v[0];
        v[0] = v[i];
        v[i] = aux;
        criaHeap(v, 0, i - 1);
    }
}


void Ordena_insertionSort(int *v, int n){
 int i, j, aux;

 for(i = 1; i < n; i++){

    aux = v[i];
    for(j = i; (j > 0) && (aux < v[j-1]);j--){
        v[j] = v[j - 1];

    }
    v[j] = aux;
 }

}

void merge(int *v, int inicio, int meio, int fim){
    int *temp, p1,p2,tamanho,i,j,k;
    int fim1 = 0,fim2 = 0;
    tamanho = fim - inicio +1;
    p1= inicio;
    p2 = meio +1;
    temp = (int*)malloc(tamanho * sizeof(int));
    if (temp != NULL){
        for(i = 0; i< tamanho; i++){
        if(!fim1 && !fim2){
            if(v[p1] < v[p2]){
                temp[i] = v[p1];
                p1++;
            }else{
                temp[i] = v[p2];
                p2++;
			}
            if(p1 > meio){
                fim1 = 1;
            }
            if(p2 > fim){
                fim2 = 1;
            }
        }else{

            if(!fim1){
                temp[i] = v[p1++];
            }else{
                temp[i] = v[p2++];
            }
        }
        }
        for(j = 0, k = inicio; j < tamanho; j++, k++){
        v[k] = temp[j];
        }
    }
free(temp);
}

void Ordena_mergeSort(int *v, int inicio, int fim){
    int meio;
    if(inicio<fim){
        meio = (inicio + fim)/2;
        Ordena_mergeSort(v,inicio,meio);
        Ordena_mergeSort(v,meio +1,fim);
        merge(v, inicio, meio, fim);
    }
}

int particiona(int *v, int inicio, int fim){
    int esq, dir, pivo, aux;
    esq = inicio;
    dir = fim;
    pivo = v[inicio];

    while(esq<dir){
        while(v[esq]<=pivo){
            esq++;
        }
        while(v[dir]>pivo){
            dir--;
        }
        if(esq<dir){
            aux = v[esq];
            v[esq]=v[dir];
            v[dir]=aux;
        }
    }
    v[inicio] = v[dir];
    v[dir]=pivo;
    return dir;
}


void Ordena_quickSort(int *v, int inicio, int fim){
    int pivo;
    if (fim>inicio){
        pivo = particiona(v,inicio,fim);
        Ordena_quickSort(v, inicio, pivo - 1);
        Ordena_quickSort(v,pivo+1,fim);
    }
}



void Ordena_selectionSort(int *v, int n){

    int i, j, menor, troca;
    for(i = 0; i < n - 1; i++){
        menor = i;
        for(j = i + 1; j < n; j++){
            if (v[j] < v[menor]){
                menor = j;
            }
        }
        if(i != menor){
            troca = v[i];
            v[i] = v[menor];
            v[menor] = troca;
        }
    }
}

void Ordena_shellSort(int *vet, int size){
    int i , j , value;
    int gap = 1;
    while(gap < size) {
        gap = 3*gap+1;
    }
    while ( gap > 1) {
        gap = gap / 3;
        for(i = gap; i < size; i++){
            value = vet[i];
            j = i - gap;
            while (j >= 0 && value < vet[j]) {
                vet [j + gap] = vet[j];
                j =j - gap;
            }
                vet [j + gap] = value;
        }
    }
}

int tempoOperacao(int opcao){
    int i, qtd, zerar;
    int *vetor;
    int cont = 0;
    clock_t Ticks[2];
    double tempoOrd[12];
    double Tempo;

    for(zerar = 0; zerar <= 12; zerar++){


        tempoOrd[zerar] = 0;
    }
    qtd = escolheqtd();

    do{
        Ticks[0] = clock();
        vetor = alocavetor(qtd);
        atribuiElementos(vetor, qtd);

    switch(opcao){

            case 1:
            printf("\n\t\t -------- Ordenando em BubbleSort------------\n");
            Ordena_bubbleSort(vetor, qtd);
            Ticks[1] = clock();
            Tempo = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;

            if(cont > 9){

                tempoOrd[10] = Tempo;
                printf("\n\n\n\t\tTempo gasto com vetor ja ordenado : %g ms.", Tempo);

                mediaTempoOrd(tempoOrd);

                inverter(vetor,qtd);
                Ticks[0] = clock();
                Ordena_bubbleSort(vetor, qtd);
                Ticks[1] = clock();
                Tempo = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;
                tempoOrd[11] = Tempo;
                printf("\n\t\tTempo gasto com vetor invertido: %g ms.\n\n", Tempo);

            }

            break;

            case 2:
            printf("\n\t\t -------- Ordenando em HeapSort------------\n");
            Ordena_heapSort(vetor, qtd);
            Ticks[1] = clock();
            Tempo = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;

            if(cont > 9){

            tempoOrd[10] = Tempo;
            printf("\n\n\n\t\tTempo gasto com vetor ja ordenado : %g ms.", Tempo);

            mediaTempoOrd(tempoOrd);

            inverter(vetor,qtd);
            Ticks[0] = clock();
            Ordena_bubbleSort(vetor, qtd);
            Ticks[1] = clock();
            Tempo = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;
            tempoOrd[11] = Tempo;
            printf("\n\t\tTempo gasto com vetor invertido: %g ms.\n\n", Tempo);

            }
            break;

            case 3:
            printf("\n\t\t -------- Ordenando em InsertionSort------------\n");
            Ordena_insertionSort(vetor, qtd);
            Ticks[1] = clock();
            Tempo = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;

            if(cont > 9){

            tempoOrd[10] = Tempo;
            printf("\n\n\n\t\tTempo gasto com vetor ja ordenado : %g ms.", Tempo);

            mediaTempoOrd(tempoOrd);

            inverter(vetor,qtd);
            Ticks[0] = clock();
            Ordena_bubbleSort(vetor, qtd);
            Ticks[1] = clock();
            Tempo = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;
            tempoOrd[11] = Tempo;
            printf("\n\t\tTempo gasto com vetor invertido: %g ms.\n\n", Tempo);

            }
            break;

            case 4:
            printf("\n\t\t -------- Ordenando em MergeSort------------\n");
            Ordena_mergeSort(vetor, vetor[0], vetor[qtd-1]);
            Ticks[1] = clock();
            Tempo = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;

            if(cont > 9){

                tempoOrd[10] = Tempo;
                printf("\n\n\n\t\tTempo gasto com vetor ja ordenado : %g ms.", Tempo);

                mediaTempoOrd(tempoOrd);

                inverter(vetor,qtd);
                Ticks[0] = clock();
                Ordena_bubbleSort(vetor, qtd);
                Ticks[1] = clock();
                Tempo = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;
                tempoOrd[11] = Tempo;
                printf("\n\t\tTempo gasto com vetor invertido: %g ms.\n\n", Tempo);

            }
            break;

            case 5:
            printf("\n\t\t -------- Ordenando em QuickSort------------\n");
            Ordena_quickSort(vetor, vetor[0], vetor[qtd-1]);
            Ticks[1] = clock();
            Tempo = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;

            if(cont > 9){

                tempoOrd[10] = Tempo;
                printf("\n\n\n\t\tTempo gasto com vetor ja ordenado : %g ms.", Tempo);

                mediaTempoOrd(tempoOrd);

                inverter(vetor,qtd);
                Ticks[0] = clock();
                Ordena_bubbleSort(vetor, qtd);
                Ticks[1] = clock();
                Tempo = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;
                tempoOrd[11] = Tempo;
                printf("\n\t\tTempo gasto com vetor invertido: %g ms.\n\n", Tempo);

            }

            break;

            case 6:
            printf("\n\t\t -------- Ordenando em SelectionSort------------\n");
            Ordena_selectionSort(vetor, qtd);
            Ticks[1] = clock();
            Tempo = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;

            if(cont > 9){

                tempoOrd[10] = Tempo;
                printf("\n\n\n\t\tTempo gasto com vetor ja ordenado : %g ms.", Tempo);

                mediaTempoOrd(tempoOrd);

                inverter(vetor,qtd);
                Ticks[0] = clock();
                Ordena_bubbleSort(vetor, qtd);
                Ticks[1] = clock();
                Tempo = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;
                tempoOrd[11] = Tempo;
                printf("\n\t\tTempo gasto com vetor invertido: %g ms.\n\n", Tempo);

            }
            break;

            case 7:
            printf("\n\t\t -------- Ordenando em ShellSort------------\n");
            Ordena_shellSort(vetor, qtd);
            Ticks[1] = clock();
            Tempo = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;

            if(cont > 9){

                tempoOrd[10] = Tempo;
                printf("\n\n\n\t\tTempo gasto com vetor ja ordenado : %g ms.", Tempo);

                mediaTempoOrd(tempoOrd);

                inverter(vetor,qtd);
                Ticks[0] = clock();
                Ordena_bubbleSort(vetor, qtd);
                Ticks[1] = clock();
                Tempo = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;
                tempoOrd[11] = Tempo;
                printf("\n\t\tTempo gasto com vetor invertido: %g ms.\n\n", Tempo);

            }
            break;


        }

        tempoOrd[cont] = Tempo;

        if(cont <= 9){
            printf("\n\t\t\t\tTempo gasto: %g ms.\n", Tempo);
        }

        free(vetor);


    cont++;
    }while(cont <= 10);
}

