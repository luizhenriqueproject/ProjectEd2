/* Fun��es Auxiliares */
void inverter(int v*,int n);
int escolheqtd{);
void atribuiElementos();
int alocavetor(int qtd);
void mediaTempoOrd(double vetor);

/* Fun��es de Ordena��o */
void Ordena_bubbleSort(int *v, int n);
void Ordena_insertionSort(int *v, int n);
void criaHeap(int *v, int i, int f);
void Ordena_heapSort(int *v, int n);

void Ordena_mergeSort(int *v, int inicio, int fim);
void merge(int *v, int inicio, int meio, int fim);

void Ordena_quickSort(int *v, int fim);
int particiona(int *v, int inicio, int fim);
void Ordena_selectionSort(int *v, int n);
void Ordena_shellSort(int *vet, int size);

int tempoOperacao(int opcao);



