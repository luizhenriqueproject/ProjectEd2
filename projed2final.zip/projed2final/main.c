#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main()
{
    int opcao, qtd;

    setlocale(LC_ALL,"Portuguese");

    do{
        //system("cls");
        printf("\t|----------------------------------------------------------|\n");
        printf("\t|-------  DESEMPENHO DE ALGORITMOS DE ORDENA��O  ----------|\n");
        printf("\t|--------------  Bem vindo ao nosso projeto! --------------|\n");
        printf("\t|----------------------------------------------------------|\n");
        printf("\t|------------  Digite a op��o que voc� deseja: ------------|\n\n\n\n");

        printf("\t Digite 1 para BubbleSort \n");
        printf("\t Digite 2 para HeapSort \n");
        printf("\t Digite 3 para InsertionSort \n");
        printf("\t Digite 4 para MergeSort \n");
        printf("\t Digite 5 para QuickSort \n");
        printf("\t Digite 6 para SelectionSort \n");
        printf("\t Digite 7 para ShellSort \n");
        printf("\t Digite 0 para encerrar o programa \n\n");
        printf("\t\t\t\t\t");
        scanf("%d", &opcao);
        system("cls");
        switch(opcao){

            case 0:
            printf("Saindo do programa...");
            break;

            case 1:
            printf("\n\t\t ------------Fun��o BubbleSort------------\n");
            tempoOperacao(opcao);

            break;

            case 2:
            printf("\n\t\t ------------Fun��o HeapSort------------\n");
            tempoOperacao(opcao);
            break;

            case 3:
            printf("\n\t\t ------------Fun��o InsertionSort------------\n");
            tempoOperacao(opcao);
            break;

            case 4:
            printf("\n\t\t ------------Fun��o MergeSort------------\n");
            tempoOperacao(opcao);
            break;

            case 5:
            printf("\n\t\t ------------Fun��o QuickSort------------\n");
            tempoOperacao(opcao);
            break;

            case 6:
            printf("\n\t\t ------------Fun��o SelectionSort------------\n");
            tempoOperacao(opcao);
            break;

            case 7:
            printf("\n\t\t ------------Fun��o ShellSort------------\n");
            tempoOperacao(opcao);
            break;

            default:
            system("cls");
            printf("\t\t\tOp��o inv�lida!\n\n\n\n ");
            break;

        }
    }while(opcao != 0);
    printf("\n\n");
    return 0;
}
